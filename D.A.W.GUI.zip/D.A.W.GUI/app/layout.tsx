import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'D.A.W.GUI',
  description: 'Created for Dynamic Autonomous Wandering Guide (D.A.W.G 2025)',
  generator: 'abyaz34',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
