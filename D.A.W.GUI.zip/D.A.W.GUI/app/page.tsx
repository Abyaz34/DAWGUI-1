import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { MapPin, Map, Settings } from "lucide-react"

export default function HomePage() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="bg-blue-700 text-white p-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <h1 className="text-2xl font-bold">D.A.W.G</h1>
        </div>
        <Link href="/admin">
          <Button variant="ghost" className="text-white hover:bg-blue-600 hover:text-white">
            <Settings className="mr-2 h-4 w-4" />
            Admin
          </Button>
        </Link>
      </header>

      <main className="flex-1 container mx-auto p-4 md:p-8">
        <section className="mb-8">
          <h2 className="text-3xl font-bold text-center mb-8">Welcome to UOWD</h2>
          <p className="text-xl text-center mb-8">I'm D.A.W.G, your robotic guide dog. How can I help you today?</p>
        </section>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          <Link href="/destinations" className="block">
            <Card className="h-full transition-all hover:shadow-lg">
              <CardContent className="p-8 flex flex-col items-center text-center">
                <MapPin className="h-16 w-16 text-blue-600 mb-4" />
                <h3 className="text-2xl font-bold mb-2">Take Me Somewhere</h3>
                <p className="text-gray-600">Select a destination and I'll guide you there</p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/tour" className="block">
            <Card className="h-full transition-all hover:shadow-lg">
              <CardContent className="p-8 flex flex-col items-center text-center">
                <Map className="h-16 w-16 text-blue-600 mb-4" />
                <h3 className="text-2xl font-bold mb-2">Guided Tour</h3>
                <p className="text-gray-600">Take a complete tour of the area with informative stops</p>
              </CardContent>
            </Card>
          </Link>
        </div>
      </main>

      <footer className="bg-gray-100 p-4 text-center text-gray-600">
        <p>D.A.W.G | Unitree Go1 EDU</p>
      </footer>
    </div>
  )
}
