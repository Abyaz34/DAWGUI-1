"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowLeft, Navigation, Home } from "lucide-react"
import { MapDisplay } from "@/components/map-display"
import { RobotStatus } from "@/components/robot-status"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Mock data for destinations organized by floor
const destinationsByFloor = {
  0: [
    { id: 1, name: "Lecture Hall", description: "Main lecture theater" },
    { id: 2, name: "Food Court", description: "Cafeteria and dining area" },
    { id: 3, name: "Exhibition Hall", description: "Current exhibitions and displays" },
    { id: 4, name: "Offices", description: "Faculty and staff offices" },
    { id: 5, name: "Concrete Lab", description: "Civil engineering concrete testing lab" },
  ],
  1: [
    { id: 6, name: "FRED", description: "Faculty research and education development" },
    { id: 7, name: "Student Lounge", description: "Relaxation and study area" },
    { id: 8, name: "Cashiers", description: "Payment and financial services" },
    { id: 9, name: "Student Life Office", description: "Student activities and support" },
    { id: 10, name: "Counsellors", description: "Student counselling services" },
    { id: 11, name: "Computer Lab", description: "General computer facilities" },
    { id: 12, name: "Circuits Lab", description: "Electrical engineering lab" },
    { id: 13, name: "Manufacturing Lab", description: "Manufacturing and prototyping" },
    { id: 14, name: "Power Lab", description: "Electrical power systems lab" },
  ],
  2: [
    { id: 15, name: "Library", description: "Main campus library" },
    { id: 16, name: "Meeting Rooms", description: "Bookable meeting spaces" },
    { id: 17, name: "Student Services", description: "Help desk and student support" },
  ],
  3: [
    { id: 18, name: "Classrooms", description: "General purpose classrooms" },
    { id: 19, name: "Computer Labs", description: "Specialized computing facilities" },
    { id: 20, name: "IT Office", description: "Information technology support" },
    { id: 21, name: "FEIS Office", description: "Faculty of Engineering and Information Sciences" },
    { id: 22, name: "Physics Lab", description: "Physics experiments and research" },
    { id: 23, name: "Innovation Hub", description: "Collaborative innovation space" },
  ],
}

export default function DestinationsPage() {
  const [currentFloor, setCurrentFloor] = useState(0)
  const [selectedDestination, setSelectedDestination] = useState<number | null>(null)
  const [isNavigating, setIsNavigating] = useState(false)

  const handleStartNavigation = () => {
    if (selectedDestination !== null) {
      setIsNavigating(true)
      // In a real implementation, this would trigger the ROS navigation
    }
  }

  const handleCancelNavigation = () => {
    setIsNavigating(false)
    setSelectedDestination(null)
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="bg-blue-700 text-white p-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/">
            <Button variant="ghost" className="text-white hover:bg-blue-600 p-2">
              <ArrowLeft className="h-6 w-6" />
            </Button>
          </Link>
          <h1 className="text-2xl font-bold">Select Destination</h1>
        </div>
      </header>

      <main className="flex-1 container mx-auto p-4 grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1 space-y-4">
          <h2 className="text-xl font-bold mb-4">Available Destinations</h2>

          {isNavigating ? (
            <div className="space-y-4">
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <h3 className="font-bold text-blue-700">
                  Currently navigating to:{" "}
                  {
                    destinationsByFloor[currentFloor as keyof typeof destinationsByFloor].find(
                      (d) => d.id === selectedDestination,
                    )?.name
                  }
                </h3>
                <p className="text-sm text-blue-600 mt-1">Please follow me. I'll guide you to your destination.</p>
              </div>

              <Button
                variant="outline"
                className="w-full border-red-300 text-red-600 hover:bg-red-50"
                onClick={handleCancelNavigation}
              >
                Cancel Navigation
              </Button>

              <Button className="w-full bg-blue-600 hover:bg-blue-700" onClick={handleCancelNavigation}>
                <Home className="mr-2 h-4 w-4" />
                Return to Home Base
              </Button>
            </div>
          ) : (
            <>
              <Tabs defaultValue="0" onValueChange={(value) => setCurrentFloor(Number.parseInt(value))}>
                <TabsList className="grid grid-cols-4 mb-4">
                  <TabsTrigger value="0">Floor 0</TabsTrigger>
                  <TabsTrigger value="1">Floor 1</TabsTrigger>
                  <TabsTrigger value="2">Floor 2</TabsTrigger>
                  <TabsTrigger value="3">Floor 3</TabsTrigger>
                </TabsList>

                {Object.entries(destinationsByFloor).map(([floor, locations]) => (
                  <TabsContent key={floor} value={floor} className="space-y-2">
                    {locations.map((destination) => (
                      <Card
                        key={destination.id}
                        className={`cursor-pointer transition-all ${
                          selectedDestination === destination.id ? "border-blue-500 bg-blue-50" : ""
                        }`}
                        onClick={() => setSelectedDestination(destination.id)}
                      >
                        <CardContent className="p-4">
                          <h3 className="font-bold">{destination.name}</h3>
                          <p className="text-sm text-gray-600">{destination.description}</p>
                        </CardContent>
                      </Card>
                    ))}
                  </TabsContent>
                ))}
              </Tabs>

              <Button
                className="w-full bg-blue-600 hover:bg-blue-700"
                disabled={selectedDestination === null}
                onClick={handleStartNavigation}
              >
                <Navigation className="mr-2 h-4 w-4" />
                Start Navigation
              </Button>
            </>
          )}

          <RobotStatus isNavigating={isNavigating} />
        </div>

        <div className="md:col-span-2">
          <MapDisplay
            selectedDestination={selectedDestination}
            isNavigating={isNavigating}
            currentFloor={currentFloor}
          />
        </div>
      </main>
    </div>
  )
}
