"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, Play, Pause, SkipForward, Home } from "lucide-react"
import { MapDisplay } from "@/components/map-display"
import { RobotStatus } from "@/components/robot-status"

// Mock data for tours
const tours = [
  {
    id: 1,
    name: "Campus Highlights",
    description: "A 15-minute tour of the main campus attractions",
    duration: "15 min",
    stops: 5,
  },
  {
    id: 2,
    name: "Research Facilities",
    description: "Explore our cutting-edge research labs and facilities",
    duration: "20 min",
    stops: 6,
  },
]

export default function TourPage() {
  const [selectedTour, setSelectedTour] = useState<number | null>(null)
  const [isOnTour, setIsOnTour] = useState(false)
  const [isPaused, setIsPaused] = useState(false)
  const [currentStop, setCurrentStop] = useState(1)

  const handleStartTour = () => {
    if (selectedTour !== null) {
      setIsOnTour(true)
      setCurrentStop(1)
      // In a real implementation, this would trigger the ROS navigation
    }
  }

  const handlePauseTour = () => {
    setIsPaused(!isPaused)
    // In a real implementation, this would pause/resume the ROS navigation
  }

  const handleNextStop = () => {
    const selectedTourData = tours.find((t) => t.id === selectedTour)
    if (selectedTourData && currentStop < selectedTourData.stops) {
      setCurrentStop(currentStop + 1)
      // In a real implementation, this would trigger navigation to the next stop
    } else {
      // End of tour
      handleEndTour()
    }
  }

  const handleEndTour = () => {
    setIsOnTour(false)
    setIsPaused(false)
    setSelectedTour(null)
    setCurrentStop(1)
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="bg-blue-700 text-white p-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/">
            <Button variant="ghost" className="text-white hover:bg-blue-600 p-2">
              <ArrowLeft className="h-6 w-6" />
            </Button>
          </Link>
          <h1 className="text-2xl font-bold">Guided Tours</h1>
        </div>
      </header>

      <main className="flex-1 container mx-auto p-4 grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1 space-y-4">
          <h2 className="text-xl font-bold mb-4">Available Tours</h2>

          {isOnTour ? (
            <div className="space-y-4">
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <h3 className="font-bold text-blue-700">{tours.find((t) => t.id === selectedTour)?.name}</h3>
                <p className="text-sm text-blue-600 mt-1">
                  Stop {currentStop} of {tours.find((t) => t.id === selectedTour)?.stops}
                </p>
                <p className="text-sm text-gray-600 mt-2">
                  {isPaused ? "Tour paused. Press resume when ready." : "Please follow me to the next location."}
                </p>
              </div>

              <div className="flex gap-2">
                <Button variant="outline" className="flex-1" onClick={handlePauseTour}>
                  {isPaused ? (
                    <>
                      <Play className="mr-2 h-4 w-4" />
                      Resume
                    </>
                  ) : (
                    <>
                      <Pause className="mr-2 h-4 w-4" />
                      Pause
                    </>
                  )}
                </Button>

                <Button variant="outline" className="flex-1" onClick={handleNextStop}>
                  <SkipForward className="mr-2 h-4 w-4" />
                  Next Stop
                </Button>
              </div>

              <Button
                variant="outline"
                className="w-full border-red-300 text-red-600 hover:bg-red-50"
                onClick={handleEndTour}
              >
                End Tour
              </Button>

              <Button className="w-full bg-blue-600 hover:bg-blue-700" onClick={handleEndTour}>
                <Home className="mr-2 h-4 w-4" />
                Return to Home Base
              </Button>
            </div>
          ) : (
            <>
              <div className="space-y-2">
                {tours.map((tour) => (
                  <Card
                    key={tour.id}
                    className={`cursor-pointer transition-all ${
                      selectedTour === tour.id ? "border-blue-500 bg-blue-50" : ""
                    }`}
                    onClick={() => setSelectedTour(tour.id)}
                  >
                    <CardHeader className="p-4 pb-2">
                      <CardTitle className="text-lg">{tour.name}</CardTitle>
                    </CardHeader>
                    <CardContent className="p-4 pt-0">
                      <p className="text-sm text-gray-600 mb-2">{tour.description}</p>
                      <div className="flex justify-between text-sm">
                        <span className="text-blue-600">{tour.duration}</span>
                        <span className="text-blue-600">{tour.stops} stops</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <Button
                className="w-full bg-blue-600 hover:bg-blue-700"
                disabled={selectedTour === null}
                onClick={handleStartTour}
              >
                <Play className="mr-2 h-4 w-4" />
                Start Tour
              </Button>
            </>
          )}

          <RobotStatus isNavigating={isOnTour} />
        </div>

        <div className="md:col-span-2">
          <MapDisplay selectedTour={selectedTour} isOnTour={isOnTour} currentStop={currentStop} />
        </div>
      </main>
    </div>
  )
}
