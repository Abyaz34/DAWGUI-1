"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { ArrowLeft, Plus, Edit, Trash2, Save, GripVertical } from "lucide-react"
import { MapDisplay } from "@/components/map-display"

// Mock data for tours
const initialTours = [
  {
    id: 1,
    name: "Campus Highlights",
    description: "A 15-minute tour of the main campus attractions",
    stops: [
      { id: 1, locationId: 1, description: "This is our main lecture hall, where most large events are held." },
      { id: 2, locationId: 3, description: "Our exhibition area showcases student projects and research." },
      { id: 3, locationId: 2, description: "The food court offers a variety of dining options." },
      { id: 4, locationId: 4, description: "Our library contains over 50,000 books and digital resources." },
      { id: 5, locationId: 6, description: "Student services can help with any administrative questions." },
    ],
  },
  {
    id: 2,
    name: "Research Facilities",
    description: "Explore our cutting-edge research labs and facilities",
    stops: [
      { id: 1, locationId: 5, description: "Our computer lab is equipped with the latest technology." },
      { id: 2, locationId: 4, description: "The library houses our research archives." },
      { id: 3, locationId: 3, description: "Current research projects are displayed in the exhibition area." },
    ],
  },
]

// Mock data for locations (same as in locations page)
const locations = [
  { id: 1, name: "Lecture Hall", description: "Main lecture theater", x: 150, y: 100 },
  { id: 2, name: "Food Court", description: "Cafeteria and dining area", x: 300, y: 200 },
  { id: 3, name: "Exhibition Area", description: "Current exhibitions and displays", x: 450, y: 150 },
  { id: 4, name: "Library", description: "Main campus library", x: 200, y: 300 },
  { id: 5, name: "Computer Lab", description: "Open access computing facilities", x: 350, y: 350 },
  { id: 6, name: "Student Services", description: "Help desk and student support", x: 500, y: 300 },
]

export default function AdminToursPage() {
  const [tours, setTours] = useState(initialTours)
  const [selectedTour, setSelectedTour] = useState<number | null>(null)
  const [isEditing, setIsEditing] = useState(false)
  const [isAddingNew, setIsAddingNew] = useState(false)
  const [editedTour, setEditedTour] = useState({
    id: 0,
    name: "",
    description: "",
    stops: [{ id: 1, locationId: 1, description: "" }],
  })
  const [selectedStop, setSelectedStop] = useState<number | null>(null)

  const handleEditTour = (id: number) => {
    const tour = tours.find((t) => t.id === id)
    if (tour) {
      setEditedTour({ ...tour })
      setSelectedTour(id)
      setIsEditing(true)
      setIsAddingNew(false)
      setSelectedStop(null)
    }
  }

  const handleAddNewTour = () => {
    const newId = Math.max(...tours.map((t) => t.id), 0) + 1
    setEditedTour({
      id: newId,
      name: "New Tour",
      description: "Tour description",
      stops: [{ id: 1, locationId: 1, description: "Stop description" }],
    })
    setSelectedTour(null)
    setIsEditing(true)
    setIsAddingNew(true)
    setSelectedStop(null)
  }

  const handleDeleteTour = (id: number) => {
    setTours(tours.filter((t) => t.id !== id))
    if (selectedTour === id) {
      setSelectedTour(null)
      setIsEditing(false)
    }
  }

  const handleSaveTour = () => {
    if (isAddingNew) {
      setTours([...tours, editedTour])
    } else {
      setTours(tours.map((t) => (t.id === editedTour.id ? editedTour : t)))
    }
    setIsEditing(false)
    setIsAddingNew(false)
  }

  const handleAddStop = () => {
    const newStopId = Math.max(...editedTour.stops.map((s) => s.id), 0) + 1
    setEditedTour({
      ...editedTour,
      stops: [...editedTour.stops, { id: newStopId, locationId: 1, description: "New stop description" }],
    })
  }

  const handleDeleteStop = (stopId: number) => {
    if (editedTour.stops.length <= 1) {
      return // Don't allow deleting the last stop
    }

    setEditedTour({
      ...editedTour,
      stops: editedTour.stops.filter((s) => s.id !== stopId),
    })

    if (selectedStop === stopId) {
      setSelectedStop(null)
    }
  }

  const handleUpdateStop = (stopId: number, field: string, value: any) => {
    setEditedTour({
      ...editedTour,
      stops: editedTour.stops.map((s) => (s.id === stopId ? { ...s, [field]: value } : s)),
    })
  }

  const getLocationName = (locationId: number) => {
    const location = locations.find((l) => l.id === locationId)
    return location ? location.name : "Unknown"
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="bg-teal-700 text-white p-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/admin">
            <Button variant="ghost" className="text-white hover:bg-teal-600 p-2">
              <ArrowLeft className="h-6 w-6" />
            </Button>
          </Link>
          <h1 className="text-2xl font-bold">Configure Tours</h1>
        </div>
        <Button variant="outline" className="text-white border-white hover:bg-teal-600" onClick={handleAddNewTour}>
          <Plus className="mr-2 h-4 w-4" />
          Add Tour
        </Button>
      </header>

      <main className="flex-1 container mx-auto p-4 grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1 space-y-4">
          <h2 className="text-xl font-bold mb-4">Tour List</h2>

          {isEditing ? (
            <Card className="p-4">
              <h3 className="font-bold mb-4">{isAddingNew ? "Add New Tour" : "Edit Tour"}</h3>
              <div className="space-y-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium mb-1">
                    Tour Name
                  </label>
                  <Input
                    id="name"
                    value={editedTour.name}
                    onChange={(e) => setEditedTour({ ...editedTour, name: e.target.value })}
                  />
                </div>

                <div>
                  <label htmlFor="description" className="block text-sm font-medium mb-1">
                    Description
                  </label>
                  <Textarea
                    id="description"
                    value={editedTour.description}
                    onChange={(e) => setEditedTour({ ...editedTour, description: e.target.value })}
                    rows={2}
                  />
                </div>

                <div>
                  <div className="flex justify-between items-center mb-2">
                    <label className="block text-sm font-medium">Tour Stops</label>
                    <Button variant="outline" size="sm" className="h-8 text-xs" onClick={handleAddStop}>
                      <Plus className="h-3 w-3 mr-1" />
                      Add Stop
                    </Button>
                  </div>

                  <div className="space-y-3 max-h-60 overflow-y-auto pr-1">
                    {editedTour.stops.map((stop, index) => (
                      <div
                        key={stop.id}
                        className={`border rounded-md p-3 ${
                          selectedStop === stop.id ? "border-teal-500 bg-teal-50" : ""
                        }`}
                        onClick={() => setSelectedStop(stop.id)}
                      >
                        <div className="flex justify-between items-center mb-2">
                          <div className="flex items-center">
                            <GripVertical className="h-4 w-4 text-gray-400 mr-2" />
                            <span className="text-sm font-medium">Stop {index + 1}</span>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6 text-gray-500 hover:text-red-600"
                            onClick={(e) => {
                              e.stopPropagation()
                              handleDeleteStop(stop.id)
                            }}
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>

                        <div className="space-y-2">
                          <div>
                            <label className="block text-xs text-gray-500 mb-1">Location</label>
                            <select
                              className="w-full text-sm border rounded-md p-1"
                              value={stop.locationId}
                              onChange={(e) => handleUpdateStop(stop.id, "locationId", Number.parseInt(e.target.value))}
                            >
                              {locations.map((location) => (
                                <option key={location.id} value={location.id}>
                                  {location.name}
                                </option>
                              ))}
                            </select>
                          </div>

                          <div>
                            <label className="block text-xs text-gray-500 mb-1">Description (for TTS)</label>
                            <Textarea
                              className="text-sm min-h-[60px]"
                              value={stop.description}
                              onChange={(e) => handleUpdateStop(stop.id, "description", e.target.value)}
                              rows={2}
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex gap-2 pt-2">
                  <Button
                    variant="outline"
                    className="flex-1"
                    onClick={() => {
                      setIsEditing(false)
                      setIsAddingNew(false)
                    }}
                  >
                    Cancel
                  </Button>
                  <Button className="flex-1 bg-teal-600 hover:bg-teal-700" onClick={handleSaveTour}>
                    <Save className="mr-2 h-4 w-4" />
                    Save Tour
                  </Button>
                </div>
              </div>
            </Card>
          ) : (
            <div className="space-y-2">
              {tours.map((tour) => (
                <Card
                  key={tour.id}
                  className={`cursor-pointer transition-all ${
                    selectedTour === tour.id ? "border-teal-500 bg-teal-50" : ""
                  }`}
                  onClick={() => setSelectedTour(tour.id)}
                >
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-bold">{tour.name}</h3>
                      <div className="flex gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-gray-500 hover:text-teal-600"
                          onClick={(e) => {
                            e.stopPropagation()
                            handleEditTour(tour.id)
                          }}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-gray-500 hover:text-red-600"
                          onClick={(e) => {
                            e.stopPropagation()
                            handleDeleteTour(tour.id)
                          }}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">{tour.description}</p>
                    <div className="text-xs text-teal-600">
                      {tour.stops.length} stops:{" "}
                      {tour.stops.map((stop) => getLocationName(stop.locationId)).join(" → ")}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>

        <div className="md:col-span-2">
          <MapDisplay
            adminMode={true}
            locations={locations}
            selectedTour={selectedTour}
            editingTour={isEditing ? editedTour : null}
            selectedStop={selectedStop}
          />
        </div>
      </main>
    </div>
  )
}
