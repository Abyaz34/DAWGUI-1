"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { ArrowLeft, Lock, MapPin, Route, Settings } from "lucide-react"

export default function AdminLoginPage() {
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [isAuthenticated, setIsAuthenticated] = useState(false)

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    // In a real implementation, this would validate against a secure password
    if (password === "admin123") {
      setIsAuthenticated(true)
      setError("")
    } else {
      setError("Invalid password. Please try again.")
    }
  }

  if (isAuthenticated) {
    return (
      <div className="flex min-h-screen flex-col">
        <header className="bg-blue-700 text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Link href="/">
              <Button variant="ghost" className="text-white hover:bg-blue-600 p-2">
                <ArrowLeft className="h-6 w-6" />
              </Button>
            </Link>
            <h1 className="text-2xl font-bold">Admin Dashboard</h1>
          </div>
          <Button
            variant="outline"
            className="text-white border-white hover:bg-blue-600"
            onClick={() => setIsAuthenticated(false)}
          >
            Logout
          </Button>
        </header>

        <main className="flex-1 container mx-auto p-4 md:p-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            <Link href="/admin/locations" className="block">
              <Card className="h-full transition-all hover:shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MapPin className="h-5 w-5 text-blue-600" />
                    Manage Locations
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">Add, edit, or remove location markers on the map</p>
                </CardContent>
              </Card>
            </Link>

            <Link href="/admin/tours" className="block">
              <Card className="h-full transition-all hover:shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Route className="h-5 w-5 text-blue-600" />
                    Configure Tours
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">Create and modify guided tour routes and descriptions</p>
                </CardContent>
              </Card>
            </Link>

            <Link href="/admin/settings" className="block">
              <Card className="h-full transition-all hover:shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Settings className="h-5 w-5 text-blue-600" />
                    System Settings
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">Configure robot behavior, SLAM settings, and navigation parameters</p>
                </CardContent>
              </Card>
            </Link>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="bg-blue-700 text-white p-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/">
            <Button variant="ghost" className="text-white hover:bg-blue-600 p-2">
              <ArrowLeft className="h-6 w-6" />
            </Button>
          </Link>
          <h1 className="text-2xl font-bold">Admin Access</h1>
        </div>
      </header>

      <main className="flex-1 container mx-auto p-4 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-center flex flex-col items-center gap-2">
              <Lock className="h-8 w-8 text-blue-600" />
              Administrator Login
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <Input
                  id="password"
                  type="password"
                  placeholder="Enter admin password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
                {error && <p className="text-sm text-red-500">{error}</p>}
              </div>
              <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
                Login
              </Button>
            </form>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
