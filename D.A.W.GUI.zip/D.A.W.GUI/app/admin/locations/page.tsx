"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, Plus, Edit, Trash2, Save, Building } from "lucide-react"
import { MapDisplay } from "@/components/map-display"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog"

// Mock data for floors
const initialFloors = [
  { id: 0, name: "Floor 0" },
  { id: 1, name: "Floor 1" },
  { id: 2, name: "Floor 2" },
  { id: 3, name: "Floor 3" },
]

// Mock data for locations
const initialLocations = [
  // Floor 0
  { id: 1, name: "Lecture Hall", description: "Main lecture theater", x: 150, y: 100, floor: 0 },
  { id: 2, name: "Food Court", description: "Cafeteria and dining area", x: 300, y: 200, floor: 0 },
  { id: 3, name: "Exhibition Hall", description: "Current exhibitions and displays", x: 450, y: 150, floor: 0 },
  { id: 4, name: "Offices", description: "Faculty and staff offices", x: 200, y: 300, floor: 0 },
  { id: 5, name: "Concrete Lab", description: "Civil engineering concrete testing lab", x: 350, y: 350, floor: 0 },

  // Floor 1
  { id: 6, name: "FRED", description: "Faculty research and education development", x: 150, y: 100, floor: 1 },
  { id: 7, name: "Student Lounge", description: "Relaxation and study area", x: 300, y: 150, floor: 1 },
  { id: 8, name: "Cashiers", description: "Payment and financial services", x: 450, y: 100, floor: 1 },
  { id: 9, name: "Student Life Office", description: "Student activities and support", x: 200, y: 250, floor: 1 },
  { id: 10, name: "Counsellors", description: "Student counselling services", x: 350, y: 200, floor: 1 },

  // Floor 2
  { id: 11, name: "Library", description: "Main campus library", x: 150, y: 100, floor: 2 },
  { id: 12, name: "Meeting Rooms", description: "Bookable meeting spaces", x: 300, y: 200, floor: 2 },
  { id: 13, name: "Student Services", description: "Help desk and student support", x: 450, y: 150, floor: 2 },

  // Floor 3
  { id: 14, name: "Classrooms", description: "General purpose classrooms", x: 150, y: 100, floor: 3 },
  { id: 15, name: "Computer Labs", description: "Specialized computing facilities", x: 300, y: 200, floor: 3 },
  { id: 16, name: "IT Office", description: "Information technology support", x: 450, y: 150, floor: 3 },
]

export default function AdminLocationsPage() {
  const [floors, setFloors] = useState(initialFloors)
  const [currentFloor, setCurrentFloor] = useState(0)
  const [locations, setLocations] = useState(initialLocations)
  const [selectedLocation, setSelectedLocation] = useState<number | null>(null)
  const [isEditing, setIsEditing] = useState(false)
  const [isAddingNew, setIsAddingNew] = useState(false)
  const [newFloorName, setNewFloorName] = useState("")
  const [editedLocation, setEditedLocation] = useState({
    id: 0,
    name: "",
    description: "",
    x: 0,
    y: 0,
    floor: 0,
  })

  const handleEditLocation = (id: number) => {
    const location = locations.find((loc) => loc.id === id)
    if (location) {
      setEditedLocation({ ...location })
      setSelectedLocation(id)
      setIsEditing(true)
      setIsAddingNew(false)
    }
  }

  const handleAddNewLocation = () => {
    const newId = Math.max(...locations.map((loc) => loc.id), 0) + 1
    setEditedLocation({
      id: newId,
      name: "New Location",
      description: "Description",
      x: 250,
      y: 250,
      floor: currentFloor,
    })
    setSelectedLocation(null)
    setIsEditing(true)
    setIsAddingNew(true)
  }

  const handleDeleteLocation = (id: number) => {
    setLocations(locations.filter((loc) => loc.id !== id))
    if (selectedLocation === id) {
      setSelectedLocation(null)
      setIsEditing(false)
    }
  }

  const handleSaveLocation = () => {
    if (isAddingNew) {
      setLocations([...locations, editedLocation])
    } else {
      setLocations(locations.map((loc) => (loc.id === editedLocation.id ? editedLocation : loc)))
    }
    setIsEditing(false)
    setIsAddingNew(false)
  }

  const handleMapClick = (x: number, y: number) => {
    if (isEditing) {
      setEditedLocation({ ...editedLocation, x, y })
    }
  }

  const handleAddNewFloor = () => {
    if (newFloorName.trim() === "") return

    const newFloorId = Math.max(...floors.map((f) => f.id), 0) + 1
    const newFloor = {
      id: newFloorId,
      name: newFloorName.trim(),
    }

    setFloors([...floors, newFloor])
    setCurrentFloor(newFloorId)
    setNewFloorName("")
  }

  const filteredLocations = locations.filter((loc) => loc.floor === currentFloor)

  return (
    <div className="flex min-h-screen flex-col">
      <header className="bg-blue-700 text-white p-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/admin">
            <Button variant="ghost" className="text-white hover:bg-blue-600 p-2">
              <ArrowLeft className="h-6 w-6" />
            </Button>
          </Link>
          <h1 className="text-2xl font-bold">Manage Locations</h1>
        </div>
        <div className="flex gap-2">
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline" className="text-white border-white hover:bg-blue-600">
                <Building className="mr-2 h-4 w-4" />
                Add Floor
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New Floor</DialogTitle>
              </DialogHeader>
              <div className="py-4">
                <label className="block text-sm font-medium mb-2">Floor Name</label>
                <Input
                  value={newFloorName}
                  onChange={(e) => setNewFloorName(e.target.value)}
                  placeholder="e.g., Floor 4"
                />
              </div>
              <DialogFooter>
                <Button onClick={handleAddNewFloor} className="bg-blue-600 hover:bg-blue-700">
                  Add Floor
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          <Button
            variant="outline"
            className="text-white border-white hover:bg-blue-600"
            onClick={handleAddNewLocation}
          >
            <Plus className="mr-2 h-4 w-4" />
            Add Location
          </Button>
        </div>
      </header>

      <main className="flex-1 container mx-auto p-4 grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Floor Selection</CardTitle>
            </CardHeader>
            <CardContent>
              <Tabs value={currentFloor.toString()} onValueChange={(value) => setCurrentFloor(Number(value))}>
                <TabsList className="grid" style={{ gridTemplateColumns: `repeat(${floors.length}, 1fr)` }}>
                  {floors.map((floor) => (
                    <TabsTrigger key={floor.id} value={floor.id.toString()}>
                      {floor.name}
                    </TabsTrigger>
                  ))}
                </TabsList>
              </Tabs>
            </CardContent>
          </Card>

          <h2 className="text-xl font-bold mb-4">Location List</h2>

          {isEditing ? (
            <Card className="p-4">
              <h3 className="font-bold mb-4">{isAddingNew ? "Add New Location" : "Edit Location"}</h3>
              <div className="space-y-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium mb-1">
                    Location Name
                  </label>
                  <Input
                    id="name"
                    value={editedLocation.name}
                    onChange={(e) => setEditedLocation({ ...editedLocation, name: e.target.value })}
                  />
                </div>

                <div>
                  <label htmlFor="description" className="block text-sm font-medium mb-1">
                    Description
                  </label>
                  <Textarea
                    id="description"
                    value={editedLocation.description}
                    onChange={(e) => setEditedLocation({ ...editedLocation, description: e.target.value })}
                    rows={3}
                  />
                </div>

                <div>
                  <label htmlFor="floor" className="block text-sm font-medium mb-1">
                    Floor
                  </label>
                  <select
                    id="floor"
                    className="w-full border rounded-md p-2"
                    value={editedLocation.floor}
                    onChange={(e) => setEditedLocation({ ...editedLocation, floor: Number(e.target.value) })}
                  >
                    {floors.map((floor) => (
                      <option key={floor.id} value={floor.id}>
                        {floor.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="x" className="block text-sm font-medium mb-1">
                      X Position
                    </label>
                    <Input
                      id="x"
                      type="number"
                      value={editedLocation.x}
                      onChange={(e) => setEditedLocation({ ...editedLocation, x: Number.parseInt(e.target.value) })}
                    />
                  </div>
                  <div>
                    <label htmlFor="y" className="block text-sm font-medium mb-1">
                      Y Position
                    </label>
                    <Input
                      id="y"
                      type="number"
                      value={editedLocation.y}
                      onChange={(e) => setEditedLocation({ ...editedLocation, y: Number.parseInt(e.target.value) })}
                    />
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    className="flex-1"
                    onClick={() => {
                      setIsEditing(false)
                      setIsAddingNew(false)
                    }}
                  >
                    Cancel
                  </Button>
                  <Button className="flex-1 bg-blue-600 hover:bg-blue-700" onClick={handleSaveLocation}>
                    <Save className="mr-2 h-4 w-4" />
                    Save
                  </Button>
                </div>
              </div>
            </Card>
          ) : (
            <div className="space-y-2">
              {filteredLocations.length > 0 ? (
                filteredLocations.map((location) => (
                  <Card
                    key={location.id}
                    className={`cursor-pointer transition-all ${
                      selectedLocation === location.id ? "border-blue-500 bg-blue-50" : ""
                    }`}
                    onClick={() => setSelectedLocation(location.id)}
                  >
                    <CardContent className="p-4 flex justify-between items-center">
                      <div>
                        <h3 className="font-bold">{location.name}</h3>
                        <p className="text-sm text-gray-600">{location.description}</p>
                      </div>
                      <div className="flex gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-gray-500 hover:text-blue-600"
                          onClick={(e) => {
                            e.stopPropagation()
                            handleEditLocation(location.id)
                          }}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-gray-500 hover:text-red-600"
                          onClick={(e) => {
                            e.stopPropagation()
                            handleDeleteLocation(location.id)
                          }}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <div className="text-center p-4 bg-gray-50 rounded-md">
                  <p className="text-gray-500">No locations on this floor yet.</p>
                  <Button variant="link" className="text-blue-600 mt-2" onClick={handleAddNewLocation}>
                    Add your first location
                  </Button>
                </div>
              )}
            </div>
          )}
        </div>

        <div className="md:col-span-2">
          <MapDisplay
            adminMode={true}
            locations={locations}
            selectedLocation={selectedLocation}
            editingLocation={isEditing ? editedLocation : null}
            onMapClick={handleMapClick}
            currentFloor={currentFloor}
          />
        </div>
      </main>
    </div>
  )
}
