"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, Save, RefreshCw, Volume2, VolumeX, Pause } from "lucide-react"

export default function AdminSettingsPage() {
  const [activeTab, setActiveTab] = useState("navigation")

  // Navigation settings
  const [maxSpeed, setMaxSpeed] = useState(0.5)
  const [rotationSpeed, setRotationSpeed] = useState(0.3)
  const [obstacleDistance, setObstacleDistance] = useState(0.5)
  const [returnToBase, setReturnToBase] = useState(true)

  // SLAM settings
  const [slamMethod, setSlamMethod] = useState("gmapping")
  const [mapResolution, setMapResolution] = useState(0.05)
  const [updateRate, setUpdateRate] = useState(5)
  const [saveMapOnExit, setSaveMapOnExit] = useState(true)

  // System settings
  const [volume, setVolume] = useState(80)
  const [brightness, setBrightness] = useState(70)
  const [batteryWarning, setBatteryWarning] = useState(20)
  const [autoShutdown, setAutoShutdown] = useState(false)

  // TTS settings
  const [ttsEnabled, setTtsEnabled] = useState(true)
  const [ttsSpeed, setTtsSpeed] = useState(1.0)
  const [ttsAutoStop, setTtsAutoStop] = useState(false)
  const [ttsStopDistance, setTtsStopDistance] = useState(2.0)

  const handleSaveSettings = () => {
    // In a real implementation, this would save settings to the robot
    alert("Settings saved successfully!")
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="bg-blue-700 text-white p-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/admin">
            <Button variant="ghost" className="text-white hover:bg-blue-600 p-2">
              <ArrowLeft className="h-6 w-6" />
            </Button>
          </Link>
          <h1 className="text-2xl font-bold">System Settings</h1>
        </div>
        <Button className="bg-blue-600 hover:bg-blue-700" onClick={handleSaveSettings}>
          <Save className="mr-2 h-4 w-4" />
          Save Settings
        </Button>
      </header>

      <main className="flex-1 container mx-auto p-4">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full max-w-4xl mx-auto">
          <TabsList className="grid grid-cols-4 mb-6">
            <TabsTrigger value="navigation">Navigation</TabsTrigger>
            <TabsTrigger value="slam">SLAM & Mapping</TabsTrigger>
            <TabsTrigger value="system">System</TabsTrigger>
            <TabsTrigger value="tts">Text-to-Speech</TabsTrigger>
          </TabsList>

          <TabsContent value="navigation" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Navigation Parameters</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <label className="text-sm font-medium">Maximum Speed (m/s)</label>
                    <span className="text-sm">{maxSpeed.toFixed(2)} m/s</span>
                  </div>
                  <Slider
                    value={[maxSpeed]}
                    min={0.1}
                    max={1.0}
                    step={0.05}
                    onValueChange={(value) => setMaxSpeed(value[0])}
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <label className="text-sm font-medium">Rotation Speed (rad/s)</label>
                    <span className="text-sm">{rotationSpeed.toFixed(2)} rad/s</span>
                  </div>
                  <Slider
                    value={[rotationSpeed]}
                    min={0.1}
                    max={1.0}
                    step={0.05}
                    onValueChange={(value) => setRotationSpeed(value[0])}
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <label className="text-sm font-medium">Obstacle Distance (m)</label>
                    <span className="text-sm">{obstacleDistance.toFixed(2)} m</span>
                  </div>
                  <Slider
                    value={[obstacleDistance]}
                    min={0.2}
                    max={1.0}
                    step={0.05}
                    onValueChange={(value) => setObstacleDistance(value[0])}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium">Return to Base After Task</label>
                  <Switch checked={returnToBase} onCheckedChange={setReturnToBase} />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Path Planning</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Global Planner</label>
                  <select className="w-full border rounded-md p-2">
                    <option value="navfn">NavFn</option>
                    <option value="global_planner">Global Planner</option>
                    <option value="carrot_planner">Carrot Planner</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">Local Planner</label>
                  <select className="w-full border rounded-md p-2">
                    <option value="dwa">DWA Planner</option>
                    <option value="teb">TEB Planner</option>
                    <option value="base">Base Local Planner</option>
                  </select>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="slam" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>SLAM Configuration</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">SLAM Method</label>
                  <select
                    className="w-full border rounded-md p-2"
                    value={slamMethod}
                    onChange={(e) => setSlamMethod(e.target.value)}
                  >
                    <option value="gmapping">GMapping</option>
                    <option value="cartographer">Cartographer</option>
                    <option value="rtabmap">RTAB-Map</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <label className="text-sm font-medium">Map Resolution (m/pixel)</label>
                    <span className="text-sm">{mapResolution.toFixed(3)} m/pixel</span>
                  </div>
                  <Slider
                    value={[mapResolution]}
                    min={0.01}
                    max={0.1}
                    step={0.005}
                    onValueChange={(value) => setMapResolution(value[0])}
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <label className="text-sm font-medium">Update Rate (Hz)</label>
                    <span className="text-sm">{updateRate.toFixed(1)} Hz</span>
                  </div>
                  <Slider
                    value={[updateRate]}
                    min={1}
                    max={10}
                    step={0.5}
                    onValueChange={(value) => setUpdateRate(value[0])}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium">Save Map on Exit</label>
                  <Switch checked={saveMapOnExit} onCheckedChange={setSaveMapOnExit} />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Map Management</CardTitle>
                <Button variant="outline" size="sm">
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Rebuild Map
                </Button>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Current Map</label>
                  <select className="w-full border rounded-md p-2">
                    <option value="campus_map">campus_map.pgm</option>
                    <option value="building_a">building_a.pgm</option>
                    <option value="exhibition">exhibition_hall.pgm</option>
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <Button variant="outline">Export Map</Button>
                  <Button variant="outline">Import Map</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="system" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Display & Audio</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <label className="text-sm font-medium">Volume</label>
                    <span className="text-sm">{volume}%</span>
                  </div>
                  <Slider value={[volume]} min={0} max={100} step={5} onValueChange={(value) => setVolume(value[0])} />
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <label className="text-sm font-medium">Screen Brightness</label>
                    <span className="text-sm">{brightness}%</span>
                  </div>
                  <Slider
                    value={[brightness]}
                    min={10}
                    max={100}
                    step={5}
                    onValueChange={(value) => setBrightness(value[0])}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">Text-to-Speech Voice</label>
                  <select className="w-full border rounded-md p-2">
                    <option value="en-US-female">English (US) - Female</option>
                    <option value="en-US-male">English (US) - Male</option>
                    <option value="en-GB-female">English (UK) - Female</option>
                    <option value="en-GB-male">English (UK) - Male</option>
                  </select>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Power Management</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <label className="text-sm font-medium">Low Battery Warning (%)</label>
                    <span className="text-sm">{batteryWarning}%</span>
                  </div>
                  <Slider
                    value={[batteryWarning]}
                    min={5}
                    max={50}
                    step={5}
                    onValueChange={(value) => setBatteryWarning(value[0])}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium">Auto Shutdown When Idle</label>
                  <Switch checked={autoShutdown} onCheckedChange={setAutoShutdown} />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">Idle Timeout (minutes)</label>
                  <Input type="number" min={5} max={60} value={30} disabled={!autoShutdown} />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="tts" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Text-to-Speech Controls</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {ttsEnabled ? (
                      <Volume2 className="h-5 w-5 text-blue-600" />
                    ) : (
                      <VolumeX className="h-5 w-5 text-gray-500" />
                    )}
                    <label className="text-sm font-medium">Enable Text-to-Speech</label>
                  </div>
                  <Switch checked={ttsEnabled} onCheckedChange={setTtsEnabled} />
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <label className="text-sm font-medium">Speech Rate</label>
                    <span className="text-sm">{ttsSpeed.toFixed(1)}x</span>
                  </div>
                  <Slider
                    value={[ttsSpeed]}
                    min={0.5}
                    max={2.0}
                    step={0.1}
                    onValueChange={(value) => setTtsSpeed(value[0])}
                    disabled={!ttsEnabled}
                  />
                </div>

                <div className="p-4 bg-blue-50 rounded-lg space-y-4">
                  <h3 className="font-medium flex items-center gap-2">
                    <Pause className="h-4 w-4 text-blue-600" />
                    TTS Interruption Settings
                  </h3>

                  <div className="flex items-center justify-between">
                    <label className="text-sm font-medium">Auto-stop when near destination</label>
                    <Switch checked={ttsAutoStop} onCheckedChange={setTtsAutoStop} disabled={!ttsEnabled} />
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <label className="text-sm font-medium">Stop Distance (meters)</label>
                      <span className="text-sm">{ttsStopDistance.toFixed(1)} m</span>
                    </div>
                    <Slider
                      value={[ttsStopDistance]}
                      min={0.5}
                      max={5.0}
                      step={0.5}
                      onValueChange={(value) => setTtsStopDistance(value[0])}
                      disabled={!ttsEnabled || !ttsAutoStop}
                    />
                    <p className="text-xs text-gray-500">
                      D.A.W.G will stop speaking when within this distance of the destination
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <Button variant="outline" className="flex items-center justify-center gap-2" disabled={!ttsEnabled}>
                    <Pause className="h-4 w-4" />
                    Pause All TTS
                  </Button>
                  <Button
                    variant="outline"
                    className="flex items-center justify-center gap-2 text-red-600 border-red-200 hover:bg-red-50"
                    disabled={!ttsEnabled}
                  >
                    <VolumeX className="h-4 w-4" />
                    Stop All TTS
                  </Button>
                </div>

                <div className="pt-2">
                  <h3 className="font-medium mb-2">Test Text-to-Speech</h3>
                  <div className="flex gap-2">
                    <Input
                      placeholder="Enter text to test speech"
                      defaultValue="Hello, I am D.A.W.G, your guide dog."
                      disabled={!ttsEnabled}
                    />
                    <Button disabled={!ttsEnabled} className="bg-blue-600 hover:bg-blue-700">
                      Speak
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Announcement Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium">Announce Destinations</label>
                  <Switch defaultChecked disabled={!ttsEnabled} />
                </div>

                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium">Announce Obstacles</label>
                  <Switch defaultChecked disabled={!ttsEnabled} />
                </div>

                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium">Announce Battery Status</label>
                  <Switch defaultChecked disabled={!ttsEnabled} />
                </div>

                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium">Announce Tour Information</label>
                  <Switch defaultChecked disabled={!ttsEnabled} />
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
