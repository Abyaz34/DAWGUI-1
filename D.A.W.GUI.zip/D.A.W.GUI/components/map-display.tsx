"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Card } from "@/components/ui/card"
import { MapPin } from "lucide-react"

interface Location {
  id: number
  name: string
  description: string
  x: number
  y: number
  floor?: number
}

interface Stop {
  id: number
  locationId: number
  description: string
}

interface Tour {
  id: number
  name: string
  description: string
  stops: Stop[]
}

interface MapDisplayProps {
  // User mode props
  selectedDestination?: number | null
  isNavigating?: boolean
  currentFloor?: number

  // Tour mode props
  selectedTour?: number | null
  isOnTour?: boolean
  currentStop?: number

  // Admin mode props
  adminMode?: boolean
  locations?: Location[]
  editingLocation?: Location | null
  onMapClick?: (x: number, y: number) => void
  editingTour?: Tour | null
  selectedStop?: number | null
}

export function MapDisplay({
  selectedDestination,
  isNavigating,
  currentFloor = 0,
  selectedTour,
  isOnTour,
  currentStop = 1,
  adminMode = false,
  locations = [],
  editingLocation = null,
  onMapClick,
  editingTour = null,
  selectedStop = null,
}: MapDisplayProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [isDragging, setIsDragging] = useState(false)
  const [mapScale, setMapScale] = useState(1)
  const [mapOffset, setMapOffset] = useState({ x: 0, y: 0 })

  // Mock data for the robot's current position
  const [robotPosition, setRobotPosition] = useState({ x: 100, y: 200 })

  // Mock data for the path
  const generatePath = (start: { x: number; y: number }, end: { x: number; y: number }) => {
    // In a real implementation, this would come from the ROS navigation stack
    const midX = (start.x + end.x) / 2
    const midY = (start.y + end.y) / 2 + (Math.random() - 0.5) * 50

    return [start, { x: midX, y: midY }, end]
  }

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Draw map (placeholder grid)
    ctx.save()
    ctx.translate(mapOffset.x, mapOffset.y)
    ctx.scale(mapScale, mapScale)

    // Draw grid
    ctx.strokeStyle = "#e5e5e5"
    ctx.lineWidth = 1

    for (let x = 0; x < 600; x += 50) {
      ctx.beginPath()
      ctx.moveTo(x, 0)
      ctx.lineTo(x, 400)
      ctx.stroke()
    }

    for (let y = 0; y < 400; y += 50) {
      ctx.beginPath()
      ctx.moveTo(0, y)
      ctx.lineTo(600, y)
      ctx.stroke()
    }

    // Draw walls (placeholder)
    ctx.strokeStyle = "#666"
    ctx.lineWidth = 3

    // Main outline
    ctx.beginPath()
    ctx.rect(50, 50, 500, 300)
    ctx.stroke()

    // Internal walls
    ctx.beginPath()
    ctx.moveTo(200, 50)
    ctx.lineTo(200, 200)
    ctx.stroke()

    ctx.beginPath()
    ctx.moveTo(350, 200)
    ctx.lineTo(350, 350)
    ctx.stroke()

    ctx.beginPath()
    ctx.moveTo(200, 200)
    ctx.lineTo(550, 200)
    ctx.stroke()

    // Draw floor indicator
    ctx.fillStyle = "#3b82f6" // blue-500
    ctx.font = "bold 16px Arial"
    ctx.textAlign = "left"
    ctx.fillText(`Floor ${currentFloor}`, 60, 80)

    // Draw locations
    const filteredLocations = locations.filter((loc) => loc.floor === undefined || loc.floor === currentFloor)

    filteredLocations.forEach((location) => {
      const isSelected =
        selectedDestination === location.id ||
        editingTour?.stops.some((s) => s.locationId === location.id && s.id === selectedStop)

      ctx.fillStyle = isSelected ? "#3b82f6" : "#64748b" // blue-500 or slate-500
      ctx.beginPath()
      ctx.arc(location.x, location.y, 10, 0, Math.PI * 2)
      ctx.fill()

      // Draw location name
      ctx.fillStyle = "#000"
      ctx.font = "12px Arial"
      ctx.textAlign = "center"
      ctx.fillText(location.name, location.x, location.y - 15)
    })

    // Draw editing location in admin mode
    if (adminMode && editingLocation) {
      ctx.fillStyle = "rgba(59, 130, 246, 0.5)" // blue-500 with opacity
      ctx.beginPath()
      ctx.arc(editingLocation.x, editingLocation.y, 12, 0, Math.PI * 2)
      ctx.fill()

      ctx.strokeStyle = "#3b82f6" // blue-500
      ctx.lineWidth = 2
      ctx.beginPath()
      ctx.arc(editingLocation.x, editingLocation.y, 12, 0, Math.PI * 2)
      ctx.stroke()
    }

    // Draw robot
    ctx.fillStyle = "#ef4444" // red-500
    ctx.beginPath()
    ctx.arc(robotPosition.x, robotPosition.y, 8, 0, Math.PI * 2)
    ctx.fill()

    // Draw navigation path
    if (isNavigating && selectedDestination) {
      const destination = locations.find((loc) => loc.id === selectedDestination)
      if (destination) {
        const path = generatePath(robotPosition, { x: destination.x, y: destination.y })

        ctx.strokeStyle = "#3b82f6" // blue-500
        ctx.lineWidth = 3
        ctx.setLineDash([5, 5])
        ctx.beginPath()
        ctx.moveTo(path[0].x, path[0].y)

        for (let i = 1; i < path.length; i++) {
          ctx.lineTo(path[i].x, path[i].y)
        }

        ctx.stroke()
        ctx.setLineDash([])
      }
    }

    // Draw tour path
    if ((isOnTour || editingTour) && selectedTour) {
      const tourStops = editingTour?.stops || []

      if (tourStops.length > 1) {
        ctx.strokeStyle = "#8b5cf6" // violet-500
        ctx.lineWidth = 3
        ctx.setLineDash([5, 5])
        ctx.beginPath()

        // Connect all stops
        for (let i = 0; i < tourStops.length - 1; i++) {
          const currentLoc = locations.find((loc) => loc.id === tourStops[i].locationId)
          const nextLoc = locations.find((loc) => loc.id === tourStops[i + 1].locationId)

          if (currentLoc && nextLoc) {
            if (i === 0) {
              ctx.moveTo(currentLoc.x, currentLoc.y)
            }

            // Simple curved path
            const midX = (currentLoc.x + nextLoc.x) / 2
            const midY = (currentLoc.y + nextLoc.y) / 2 + 20

            ctx.quadraticCurveTo(midX, midY, nextLoc.x, nextLoc.y)
          }
        }

        ctx.stroke()
        ctx.setLineDash([])

        // Draw stop numbers
        tourStops.forEach((stop, index) => {
          const loc = locations.find((l) => l.id === stop.locationId)
          if (loc) {
            ctx.fillStyle = "#8b5cf6" // violet-500
            ctx.beginPath()
            ctx.arc(loc.x, loc.y + 20, 10, 0, Math.PI * 2)
            ctx.fill()

            ctx.fillStyle = "#fff"
            ctx.font = "bold 10px Arial"
            ctx.textAlign = "center"
            ctx.textBaseline = "middle"
            ctx.fillText((index + 1).toString(), loc.x, loc.y + 20)
          }
        })
      }
    }

    ctx.restore()
  }, [
    locations,
    selectedDestination,
    isNavigating,
    robotPosition,
    mapScale,
    mapOffset,
    adminMode,
    editingLocation,
    selectedTour,
    isOnTour,
    currentStop,
    editingTour,
    selectedStop,
    currentFloor,
  ])

  useEffect(() => {
    if (isNavigating || isOnTour) {
      // Simulate robot movement
      const interval = setInterval(() => {
        setRobotPosition((prev) => ({
          x: prev.x + (Math.random() - 0.5) * 5,
          y: prev.y + (Math.random() - 0.5) * 5,
        }))
      }, 500)

      return () => clearInterval(interval)
    }
  }, [isNavigating, isOnTour])

  const handleCanvasMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (adminMode) {
      const canvas = canvasRef.current
      if (!canvas) return

      const rect = canvas.getBoundingClientRect()
      const x = (e.clientX - rect.left - mapOffset.x) / mapScale
      const y = (e.clientY - rect.top - mapOffset.y) / mapScale

      if (onMapClick) {
        onMapClick(x, y)
      }
    } else {
      setIsDragging(true)
    }
  }

  const handleCanvasMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (isDragging) {
      setMapOffset((prev) => ({
        x: prev.x + e.movementX,
        y: prev.y + e.movementY,
      }))
    }
  }

  const handleCanvasMouseUp = () => {
    setIsDragging(false)
  }

  const handleCanvasWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault()
    const delta = e.deltaY > 0 ? 0.9 : 1.1
    setMapScale((prev) => Math.min(Math.max(prev * delta, 0.5), 2))
  }

  return (
    <Card className="h-full">
      <div className="p-4 border-b">
        <h3 className="font-bold flex items-center gap-2">
          <MapPin className="h-4 w-4 text-blue-600" />
          Map View
          {adminMode && <span className="text-sm font-normal text-blue-600">(Click to place location)</span>}
        </h3>
      </div>
      <div className="p-4 h-[500px] overflow-hidden">
        <canvas
          ref={canvasRef}
          width={600}
          height={400}
          className="border rounded-md w-full h-full object-contain cursor-grab"
          onMouseDown={handleCanvasMouseDown}
          onMouseMove={handleCanvasMouseMove}
          onMouseUp={handleCanvasMouseUp}
          onMouseLeave={handleCanvasMouseUp}
          onWheel={handleCanvasWheel}
        />
      </div>
    </Card>
  )
}
