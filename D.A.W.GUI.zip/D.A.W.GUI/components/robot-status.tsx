"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Battery, Wifi, Activity, AlertTriangle } from "lucide-react"

interface RobotStatusProps {
  isNavigating?: boolean
}

export function RobotStatus({ isNavigating = false }: RobotStatusProps) {
  const [batteryLevel, setBatteryLevel] = useState(85)
  const [wifiStrength, setWifiStrength] = useState(75)
  const [cpuUsage, setCpuUsage] = useState(30)

  useEffect(() => {
    // Simulate changing values
    const interval = setInterval(() => {
      if (isNavigating) {
        setBatteryLevel((prev) => Math.max(prev - 0.1, 0))
        setCpuUsage((prev) => Math.min(prev + (Math.random() - 0.3) * 5, 100))
      } else {
        setBatteryLevel((prev) => Math.max(prev - 0.05, 0))
        setCpuUsage((prev) => Math.max(20, Math.min(prev + (Math.random() - 0.5) * 3, 100)))
      }
      setWifiStrength((prev) => Math.max(20, Math.min(prev + (Math.random() - 0.5) * 5, 100)))
    }, 2000)

    return () => clearInterval(interval)
  }, [isNavigating])

  const getBatteryColor = () => {
    if (batteryLevel > 50) return "text-green-500"
    if (batteryLevel > 20) return "text-yellow-500"
    return "text-red-500"
  }

  const getWifiColor = () => {
    if (wifiStrength > 60) return "text-green-500"
    if (wifiStrength > 30) return "text-yellow-500"
    return "text-red-500"
  }

  return (
    <Card>
      <CardContent className="p-4">
        <h3 className="font-bold mb-4">Robot Status</h3>

        <div className="space-y-4">
          <div className="space-y-1">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Battery className={`h-4 w-4 ${getBatteryColor()}`} />
                <span className="text-sm">Battery</span>
              </div>
              <span className={`text-sm font-medium ${getBatteryColor()}`}>{batteryLevel.toFixed(0)}%</span>
            </div>
            <Progress value={batteryLevel} className="h-2" />
          </div>

          <div className="space-y-1">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Wifi className={`h-4 w-4 ${getWifiColor()}`} />
                <span className="text-sm">Connection</span>
              </div>
              <span className="text-sm font-medium">{wifiStrength.toFixed(0)}%</span>
            </div>
            <Progress value={wifiStrength} className="h-2" />
          </div>

          <div className="space-y-1">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Activity className="h-4 w-4 text-blue-500" />
                <span className="text-sm">CPU Usage</span>
              </div>
              <span className="text-sm font-medium">{cpuUsage.toFixed(0)}%</span>
            </div>
            <Progress value={cpuUsage} className="h-2" />
          </div>

          {batteryLevel < 20 && (
            <div className="flex items-center gap-2 p-2 bg-red-50 text-red-600 rounded-md text-sm">
              <AlertTriangle className="h-4 w-4" />
              <span>Low battery warning! Please return to charging station.</span>
            </div>
          )}

          <div className="text-sm text-gray-500 pt-2">Status: {isNavigating ? "Navigating" : "Idle"}</div>
        </div>
      </CardContent>
    </Card>
  )
}
